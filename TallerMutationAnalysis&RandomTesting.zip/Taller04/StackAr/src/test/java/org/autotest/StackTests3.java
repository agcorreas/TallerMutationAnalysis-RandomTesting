package org.autotest;

import java.lang.reflect.Array;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class StackTests3 extends MutationAnalysisRunner {
    @Override
    protected boolean useVerboseMode() {
        return false;
    }

    // Tests de StackTests2

    public void testSizeIncreasesByOne() throws Exception {
        Stack stack = createStack();
        assertEquals(0, stack.size());
        stack.push(42);
        assertEquals(1, stack.size());
    }

    public void testDefaultConstructor() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
    }

    public void testConstructorWithSpecifiedCapacity() throws Exception {
        Stack stack = createStack(5);
    }

    public void testConstructorWith0Capacity() throws Exception {
        Stack stack = createStack(0);
    }
    public void testConstructorWithNegativeCapacity() {
        assertThrows(IllegalArgumentException.class, () -> {
            Stack stack = createStack(-1);
        });
    }

    public void testIsEmptyMethod() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
        stack.push(42);
        assertFalse(stack.isEmpty());
        stack.pop();
        assertTrue(stack.isEmpty());
    }

    public void testIsFullMethod() throws Exception {
        Stack stack = createStack(1);
        assertFalse(stack.isFull());
        stack.push(42);
        assertTrue(stack.isFull());
        stack.pop();
        assertFalse(stack.isFull());
    }

    public void testToStringMethod() throws Exception {
        Stack stack = createStack(2);
        assertEquals("[]", stack.toString());
        stack.push(42);
        assertEquals("[42]", stack.toString());
        stack.push(43);
        assertEquals("[42,43]", stack.toString());
    }

    // COMPLETAR
    public void testTopMethod() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertEquals(42, stack.top());
    }
    public void testTopEmptyStack() {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack = createStack();
            stack.top();
        });
    }
    public void testEqMethod1() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertTrue(stack.equals(stack));
    }
    public void testEqMethod2() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertFalse(stack.equals(null));
    }
    public void testEqMethod3() throws Exception {
        Stack stack = createStack(1);
        Stack stack1 = createStack(1);
        stack1.push(12);
        stack.push(42);
        assertFalse(stack.equals(stack1));
    }
    public void testEqMethod4() throws Exception {
        Stack stack = createStack(1);
        Stack stack1 = createStack(1);
        stack1.push(42);
        stack.push(42);
        assertTrue(stack.equals(stack1));
    }
    public void testEqMethod5() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertFalse(stack.equals("hola"));
    }
    public void testEqMethod6() throws Exception {
        Stack stack = createStack(1);
        stack.push(1);
        Stack stack1 = createStack(2);
        stack1.push(1);
        stack1.push(2);
        assertFalse(stack.equals(stack1));
    }
    public void testPopEmptyStack() {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack = createStack();
            stack.pop();
        });
    }
    public void testPushIsFullStack() {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack = createStack(1);
            stack.push(1);
            stack.push(2);
        });
    }
    public void testIsFullStack() throws Exception {
        Stack stack =createStack(2);
        stack.push(1);
        stack.push(2);
        assertTrue(stack.isFull());
    }
    public void testIsNotFullStack() throws Exception {
        Stack stack =createStack(2);
        stack.push(1);
        assertFalse(stack.isFull());
    }
    public void testReturnPopMethod() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertEquals(42, stack.pop());
    }
    public void testHashMethod() throws Exception {
        Stack stack = createStack();
        assertEquals(stack.hashCode(), 129083679);
    }


}
